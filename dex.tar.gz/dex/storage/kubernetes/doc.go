// Package kubernetes provides a storage implementation using Kubernetes third party APIs.
package kubernetes
