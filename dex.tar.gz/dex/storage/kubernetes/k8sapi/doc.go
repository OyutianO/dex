// Package k8sapi holds vendored Kubernetes types.
package k8sapi
