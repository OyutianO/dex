// Package storage defines the storage interface and types used by the server.
package storage
