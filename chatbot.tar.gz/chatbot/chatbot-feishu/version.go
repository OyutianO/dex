package chatbot

// Version is the version of lighthouse
var Version = "1.2.10"
