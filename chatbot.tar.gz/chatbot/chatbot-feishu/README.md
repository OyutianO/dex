# ChatBot Feishu - chatbot for feishu

[![PkgGoDev](https://pkg.go.dev/badge/github.com/go-zoox/chatbot-feishu)](https://pkg.go.dev/github.com/go-zoox/chatbot-feishu)
[![Build Status](https://github.com/go-zoox/chatbot-feishu/actions/workflows/ci.yml/badge.svg?branch=master)](https://github.com/go-zoox/chatbot-feishu/actions/workflows/ci.yml)
[![Go Report Card](https://goreportcard.com/badge/github.com/go-zoox/chatbot-feishu)](https://goreportcard.com/report/github.com/go-zoox/chatbot-feishu)
[![Coverage Status](https://coveralls.io/repos/github/go-zoox/chatbot-feishu/badge.svg?branch=master)](https://coveralls.io/github/go-zoox/chatbot-feishu?branch=master)
[![GitHub issues](https://img.shields.io/github/issues/go-zoox/chatbot-feishu.svg)](https://github.com/go-zoox/chatbot-feishu/issues)
[![Release](https://img.shields.io/github/tag/go-zoox/chatbot-feishu.svg?label=Release)](https://github.com/go-zoox/chatbot-feishu/tags)

## Installation
To install the package, run:
```bash
go get -u github.com/go-zoox/chatbot-feishu
```

## Getting Started

```go
// See test cases
```

## License
GoZoox is released under the [MIT License](./LICENSE).
