package main

// Version is the version of lighthouse
var Version = "1.8.7"
